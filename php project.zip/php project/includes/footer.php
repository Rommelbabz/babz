<?php

     echo "<p>Copyright &copy;2021-" . date("Y") . " Web Development  II</P>";
     ?>
     
  </body>
</html>